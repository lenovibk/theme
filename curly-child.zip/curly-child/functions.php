<?php

/*** Child Theme Function  ***/
if ( ! function_exists('curly_mkdf_child_theme_enqueue_scripts') ) {

    function curly_mkdf_child_theme_enqueue_scripts() {

        $parent_style = 'curly-mkdf-default-style';
        $modules_style = 'curly-mkdf-modules';

        wp_enqueue_style( 'curly-mkdf-child-style', get_stylesheet_directory_uri() . '/style.css', array( $parent_style, $modules_style ) );
    }

    add_action( 'wp_enqueue_scripts', 'curly_mkdf_child_theme_enqueue_scripts' );
}